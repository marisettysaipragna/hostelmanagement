Question 1-4, 9    : Voorugonda Rajesh  
Question 5-8, 16   : Venkata Sriman Narayana Malli  
Question 9-12      : Balu Karthik Ram  
Question 13-16     : Siva Sai Bommisetty  
Question 17-20, 11 : S Sri Manish Goud  


To run the files  

```
python3 zebra.py Evaluation/<file_name>
```